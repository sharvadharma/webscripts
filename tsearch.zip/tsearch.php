<div class="row" >
            <div class="col-md-12" style="height:30px;background:#0421b3;">
            <nav class="nav">
  <a class="nav-link active" href="#">Active</a>
  <a class="nav-link" href="#">Link</a>
  <a class="nav-link" href="#">Link</a>
  <a class="nav-link disabled" href="#">Disabled</a>
</nav>
            </div>
          <div class="col-md-12" style="height:60px;background:#0421b3;">
          <div class="shadow-lg p-3 mb-5 bg-white rounded">
        <center><h2 style="color:#fff;align-content:inherit;">Advanced Data Center</h2></center>    
        </div>
        </div>   
        </div> 
  <div class="row">
    <div class="col-md-12" >
      <div class="row" >
        <div class="col-md-12" >

          <form class="center" action="index.php" methode="GET">
         <div class="input-group" >
         
     <input class="form-control py-2 rounded-pill mr-1 pr-5"  type="search" id="q" name="q" value="search">
     <span class="input-group-append">
         <button class="btn rounded-pill border-0 ml-n5" type="submit">
               <i class="fa fa-search"></i>
         </button>
              </span>
             
 </div>
 </form>
            

        </div>
      </div>
