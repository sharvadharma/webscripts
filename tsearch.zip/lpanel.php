 <?php  $url1 ="http://localhost:8983/solr/hivedesc/select?facet.field=table_name&facet=on&q=*%3A*&rows=0&start=0&wt=php";

//http://localhost:8983/solr/hivedesc/select?facet.field=table_name&facet=on&q=*%3A*
          //echo $url1;
          $file1 = file_get_contents($url1); 
          eval("\$result1 = " . $file1 . ";"); 

         // for($i1=0; $i1<count($result1["facet_counts"]["facet_fields"]["facet_fields"]) ; $i1++){ 
   $param="";       
   foreach($result1["facet_counts"]["facet_fields"]["table_name"]  as $l=>$m){
    ?>
<?php 
//   display1($l,$m);
$param =$param .'{text:"'.$l .'", weight:'.$m."}," ;


//echo $param;

} ?>
    
  

<script type="text/javascript">
      var word_list = [
       <?php echo $param; ?>
      ];
      $(function() {
        $("#my_favorite_latin_words").jQCloud(word_list, {shape: "rectangular"});
      });
    </script>

                <div class="row">
        <div class="col-md-12">
          <div class="row">
          <div class="col-md-2">
          <div id="my_favorite_latin_words" style="width: 220px; height: 350px; border: 1px solid #ccc;"></div>

          <br>
        <p>
  <a class="btn btn-primary" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
    Top 10
  </a>

 
</p>
<div class="collapse" id="collapseExample">
  <div class="card card-body">
    <ul class="list-group">
  <li class="list-group-item d-flex justify-content-between align-items-center">
    Morbi leo risus
    <span class="badge badge-primary badge-pill">1</span>
  </li>
  <li class="list-group-item d-flex justify-content-between align-items-center">
    Morbi leo risus
    <span class="badge badge-primary badge-pill">1</span>
  </li>
  <li class="list-group-item d-flex justify-content-between align-items-center">
    Morbi leo risus
    <span class="badge badge-primary badge-pill">1</span>
  </li>
  <li class="list-group-item d-flex justify-content-between align-items-center">
    Morbi leo risus
    <span class="badge badge-primary badge-pill">1</span>
  </li>
  <li class="list-group-item d-flex justify-content-between align-items-center">
    Morbi leo risus
    <span class="badge badge-primary badge-pill">1</span>
  </li>
</ul>  </div>
</div>
<p>
<p>
 
 


          </div>
