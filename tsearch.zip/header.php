<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Data Discovery Center </title>

    <meta name="description" content="Source code generated using layoutit.com">
    <meta name="author" content="LayoutIt!">

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="/jqcloud/jqcloud.css" />
    <link rel="stylesheet" type="text/css" href="jqcloud/jqcloud.css" />
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.4/jquery.js"></script>

    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/scripts.js"></script>

    <script type="text/javascript" src="jqcloud/jqcloud-1.0.4.js"></script>
    
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
 
  </head>




<style>
body { background-color: #fafafa; font-family: 'Roboto Condensed'; }
.hg{color:#ff4e03 ;
font-weight: bolder;
font-size: 17px;}
.topcorner{
   position:absolute;
   top:0;
   right:0;
  }
.contain { margin:0px 150px 150px 150 px ; }
.contain a {
    text-decoration: none;
    
    display: inline-block;
    padding: 5px;
    margin: 0 7px 7px 0;
    border-radius: 5px;
}
sup {
    padding-left: 2px;
}

.center {
  margin: auto;
  width: 50%;
  
  padding: 10px;
}
</style>