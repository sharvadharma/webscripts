 <?php

if(isset($_GET["page"])){
  $page = $_GET["page"];
}
else {
  $page = 1;
}

$start = $page*10-10;
$query=$q;

$url="http://localhost:8983/solr/hivedesc/select?q=table_name%3A".$q."*"."&wt=php";


//echo $url;
$file = file_get_contents($url."&start=".$start);
eval("\$result = " . $file . ";");
$numOfPages = ceil($result["response"]["numFound"]/5);
?>


          <div class="col-md-9">
          <table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">#</th>
      <th scope="col">Table name</th>
      <th scope="col">Description</th>
      <th scope="col">Type</th>
    </tr>
  </thead>
  <tbody>

<?php

for($i=0; $i<count($result["response"]["docs"]) ; $i++){ ?>
    <tr bgcolor="#fff">
    <td><?php echo $i;?> </td>
    <td><?php echo  $result["response"]["docs"][$i]["table_name"]; ?></td>
    <td><?php echo  $result["response"]["docs"][$i]["type"]; ?></td>
    <td><?php echo  $result["response"]["docs"][$i]["description"]; ?></td>
  </tr> 
<?php
//echo "=========Result ".($i+$start+1)."=========<br>";
  
} ?> 

  </tbody>
</table>
          </div>
            
          </div>
        </div>
      </div>
      </div>

