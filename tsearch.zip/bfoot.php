<div class="row">
    <div class="col-md-12">
    <p>
    <p>
    <p> 

    Footer Text Goes Here
    </div>
  </div>
