<?php 

if(isset($_GET["q"])!=""){
  $q = $_GET["q"];
}
else {

  $q = "*%3A*";
} ?>

<?php require_once("header.php");?>

  <body>

    <div class="container-fluid">
        	<?php require_once("tsearch.php");?>
          <?php require_once("lpanel.php");?>
          <?php require_once("rpanel.php");?>
		</div>

    <?php require_once("bfoot.php");?>

    <?php require_once("footer.php");?>
    

  </body>
</html>